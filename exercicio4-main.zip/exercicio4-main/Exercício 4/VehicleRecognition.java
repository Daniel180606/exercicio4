import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class VehicleRecognition {

    public static void main(String[] args) {
        String endpoint = "https://computervisionveiculos.cognitiveservices.azure.com/";
        String apiKey = "AkWa96oErdNeqGJHVic4a8qXq9XLIEUAu3YHj3yhUdrL3Pbi6M6qJQQJ99BDACYeBjFXJ3w3AAAFACOGxiES";

        try {
            URL url = new URL(endpoint);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Ocp-Apim-Subscription-Key", apiKey);
            conn.setRequestProperty("Content-Type", "application/octet-stream");
            conn.setDoOutput(true);

            // Caminho da imagem para enviar
            File file = new File("caminho/para/sua_imagem.jpg");
            byte[] bytes = new byte[(int) file.length()];
            FileInputStream fis = new FileInputStream(file);
            fis.read(bytes);
            fis.close();

            try (OutputStream os = conn.getOutputStream()) {
                os.write(bytes, 0, bytes.length);
            }

            int responseCode = conn.getResponseCode();
            System.out.println("Response Code : " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine.trim());
            }
            in.close();

            System.out.println("Resposta do Azure:");
            System.out.println(response.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}